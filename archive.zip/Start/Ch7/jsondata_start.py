# LinkedIn Learning Python course by Joe Marini
# Example file for parsing and processing JSON
#

import urllib.request 


# Open the URL and read the data


# Read the JSON data from the source


# Print the content of the 'text' field
